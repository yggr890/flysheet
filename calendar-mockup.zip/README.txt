A Pen created at CodePen.io. You can find this one at http://codepen.io/DanielCouper/pen/eNveXy.

 Very quick mockup of calendar.